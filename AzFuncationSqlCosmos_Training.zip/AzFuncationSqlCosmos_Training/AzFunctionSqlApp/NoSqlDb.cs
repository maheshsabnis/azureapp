﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzFunctionSqlApp
{
    /// <summary>
    /// This class will be used to connect to CosmosDB
    /// and write the data from Sql Server to Document using 
    /// SQL APIs
    /// </summary>
    public  class NoSqlDb
    {
        private static readonly string Endpoint = "https://msitsou.documents.azure.com:443/";
        private static readonly string Key = "WINQMhYjvrowmqkb85r3EXfFX804qWPlvQprtaNWyQiQsqwf6FGMAXlhOn0th8LjOuT1rDI9nDUIyvYiDlmuiQ==";
        private static readonly string DatabaseId = "ProductsDB";
        private static readonly string CollectionId = "ProductsCollection";
        private static DocumentClient docClient;


        public NoSqlDb()
        {
            docClient = new DocumentClient(new Uri(Endpoint), Key);
            CreateDatabaseIfNotExistsAsync().Wait();
            CreateCollectionIfNotExistsAsync().Wait();
        }

        private static async Task CreateDatabaseIfNotExistsAsync()
        {
            try
            {
                //1.
                await docClient.ReadDatabaseAsync(UriFactory.CreateDatabaseUri(DatabaseId));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    //2.
                    await docClient.CreateDatabaseAsync(new Database { Id = DatabaseId });
                }
                else
                {
                    throw;
                }
            }
        }

        private static async Task CreateCollectionIfNotExistsAsync()
        {
            try
            {
                //1.
                await docClient.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    //2.
                    await docClient.CreateDocumentCollectionAsync(
                        UriFactory.CreateDatabaseUri(DatabaseId),
                        new DocumentCollection { Id = CollectionId },
                        new RequestOptions { OfferThroughput = 1000 });
                }
                else
                {
                    throw;
                }
            }
        }

        public  async Task AddDocumentIntoCollectionAsync(List<Products> products)
        {
            try
            {
                
                    foreach (var item in products)
                    {
                        var document = await docClient
                       .CreateDocumentAsync(UriFactory
                       .CreateDocumentCollectionUri(DatabaseId, CollectionId), item);
                        //var res = document.Resource;
                        //var person = JsonConvert.DeserializeObject<Products>(res.ToString());
                    }
                
              
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
