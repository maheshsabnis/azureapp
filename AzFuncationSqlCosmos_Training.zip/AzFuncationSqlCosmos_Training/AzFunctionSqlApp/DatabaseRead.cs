using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;

// 1. referring required namespaces
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace AzFunctionSqlApp
{
    public static class DatabaseRead
    {
        /// <summary>
        /// 2. The Function will run for every 10 seconds
        /// </summary>
        /// <param name="myTimer"></param>
        /// <param name="log"></param>
        [FunctionName("DatabaseRead")]
        public static async Task Run([TimerTrigger("*/10 * * * * *")]TimerInfo myTimer, TraceWriter log)
        {
            // 3. Get the Connection String from the app settings.
            // create a db connection form it
            var connStr = Environment.GetEnvironmentVariable("sqlserverdb_connection");
            // 4. Get List of Products from Sql Server
            List<Products> products =  SqlServerConnect.ReadData(connStr, log).Result;
            // 5. Write the Product List in CosmosDB
            var transferToNoSql = new NoSqlDb();
            await transferToNoSql.AddDocumentIntoCollectionAsync(products);

            //log.Info($"C# Timer trigger function executed at: {DateTime.Now}");
        }
    }
}
