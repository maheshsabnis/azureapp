﻿using Microsoft.Azure.WebJobs.Host;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzFunctionSqlApp
{
    public static class SqlServerConnect
    {
        public static async Task<List<Products>> ReadData(string connStr, TraceWriter log)
        {
            // 4. Convert the data in Products List
            List<Products> products = new List<Products>();
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();

                var cmdText = "Select * from Products";

                using (var cmd = new SqlCommand(cmdText, conn))
                {
                    var dataReader = await cmd.ExecuteReaderAsync();
                    log.Info("ProductRowId ProductId ProductName Manufacturer CategoryName Description BasePrice");
                    while (dataReader.Read())
                    {
                        log.Info($"{dataReader["ProductRowId"]} " +
                            $"{dataReader["ProductId"]}" +
                            $"{dataReader["ProductName"]}" +
                            $"{dataReader["Manufacturer"]}" +
                            $"{dataReader["CategoryName"]}" +
                            $"{dataReader["Description"]}" +
                            $"{dataReader["BasePrice"]}");

                        products.Add(new Products()
                        {
                            ProductRowId = Convert.ToInt32(dataReader["ProductRowId"]),
                            ProductId = dataReader["ProductId"].ToString(),
                            ProductName = dataReader["ProductName"].ToString(),
                            Manufacturer = dataReader["Manufacturer"].ToString(),
                            CategoryName = dataReader["CategoryName"].ToString(),
                            Description = dataReader["Description"].ToString(),
                            BasePrice = Convert.ToInt32(dataReader["BasePrice"])
                        });
                    }
                    dataReader.Close();
                }
                conn.Close();
            }
            return products;
        }
    }
}
